# MirrorMax

MirrorMax is an offline Android editor for still images, animated GIF, MP4, and MOV. It keeps the source aspect ratio and applies two independently configurable reflection passes. The second pass operates on the first result. Images export as PNG or H.264 MP4, GIFs as animated GIF or H.264 MP4, and video as H.264 MP4 with optional AAC audio. Android video decoding depends on the codecs installed on the device. The editor uses the system file picker and publishes to Downloads → MirrorMax → Exports via MediaStore.

Created by the Background Gremlin Group Creating Unique Tools for Unique Individuals.

## Standalone APK

Install the supplied mirrormax.apk on Android 10 or newer. The installed app does not require build tools, an SDK, Gradle, or network access. The v1.0.1 release uses the same signing certificate as the rebuilt v1.0.0 release. The initial, unrecovered v1.0.0 release was signed with a different certificate.

## Build from source

Use a Linux shell, OpenJDK 17, Android platform API 36 android.jar, and the Android build-tool executables aapt2, d8, zipalign and apksigner. Also install zip and OpenSSL on the build machine. No Gradle is used. The APK is emitted at out/mirrormax.apk.

```bash
export MIRRORMAX_BUILD_TOOLS=/absolute/path/to/build-tools
export MIRRORMAX_ANDROID_JAR=/absolute/path/to/android.jar
export MIRRORMAX_JAVA_HOME=/absolute/path/to/jdk-17
./build.sh
```

The paths must point to tools installed locally. The script calls javac, aapt2, D8, zipalign and apksigner directly. To sign an update with your own signing identity, set MIRRORMAX_KEYSTORE, MIRRORMAX_KEYPASS_FILE and MIRRORMAX_KEY_ALIAS before running it. Without those settings a local key is generated if none exists. A local development key does not update a release signed by someone else. The release signing key and its password are not distributed in this archive.

## Tests

Run `./test/run-core.sh` with Python, Pillow, and the JDK. The test checks two-pass coordinate mapping and GIF codec interoperability. The Android integration harness under `test/android` builds an instrumentation APK against the app classes, runs it on an Android device or emulator, invokes the release export engine, validates MediaStore placement, and independently decodes the resulting files. The harness must use the same signing key as the app it tests. Run it on a dedicated test device. It leaves its exported test files intact for independent inspection. The interactive desktop renderer and its input assets are included under test.
