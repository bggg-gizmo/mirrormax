# MirrorMax resend
- Previous delivery APK and source expired from transient storage and no saved copy exists.
- Restore standalone Java/DEX APK with portrait and landscape editor, two ordered mirror passes, preview, comparison, source audio, export library, sharing and original-format/MP4 exports.
- Preserve package identity. New signing key required because previous signing material wasn't recoverable.

## Original visual restoration and Android verification
- Baseline: version 1.0.0 rebuilt APK, signed certificate SHA-256 d3ffb7ebe35a075167ae2ea98b8957592f0faa7e117ac0308da7bace4e4c5eef. Preserve this signer for in-place upgrades.
- Restore original generator for Desert Dusk, original launcher icon and empty-state artwork, and original in-editor mark. Layout and workflow changes restricted to restoring original styling.
- Verify source asset bytes and visual render, signed APK payload, and any actual Android media/storage smoke test separately.
- Palette reference confirmed against the first posted editor screenshot. Near-black surfaces, green primary actions and pass-one state, purple pass-two and mirror controls. Layout unchanged.
- User approved the layout and requested vivid slime green instead of the muted green. Use #BAFF46 across editor and native branding, with a distinguishable inactive export state.
- Android 11 / API 30 instrumentation: PNG and GIF exports, still/GIF/video/MOV to H.264, MP4 with and without audio, and actual MediaStore placement passed. Independent FFmpeg/Pillow validation matched the two-pass effect and confirmed output timing and tracks.
- Fixed AAC edit-list priming: an initial negative PTS is valid and is no longer mistaken for an empty audio track.
- The Android preview now waits for the measured surface size and redraws against the actual EGL buffer when the preview is resized.
